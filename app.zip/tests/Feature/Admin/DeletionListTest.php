<?php

declare(strict_types=1);

namespace Tests\Feature\Admin;

use App\Enums\PaymentStatus;
use App\Enums\StaffRole;
use App\Livewire\Admin\DeletionList;
use App\Models\Biodata;
use App\Models\Payment;
use App\Models\User;
use App\Services\Admin\DeletionPauseReasons;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Livewire\Livewire;
use Tests\Concerns\CreatesStaff;
use Tests\TestCase;

class DeletionListTest extends TestCase
{
    use CreatesStaff;
    use RefreshDatabase;

    /** A member who asked for deletion; $daysAhead is negative when the date has passed. */
    private function waiting(int $daysAhead = 10, array $attributes = []): User
    {
        $user = User::factory()->create($attributes);
        $user->forceFill([
            'deletion_requested_at' => now()->subDays(14 - $daysAhead),
            'deletion_scheduled_for' => now()->addDays($daysAhead),
        ])->save();

        return $user;
    }

    private function openReport(Biodata $biodata, string $code): void
    {
        DB::table('reports')->insert([
            'code' => $code,
            'reporter_user_id' => User::factory()->create()->id,
            'biodata_id' => $biodata->id,
            'reported_code' => $biodata->public_code,
            'reason' => 'fake',
            'status' => 'open',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function test_a_guest_is_sent_to_login(): void
    {
        $this->get(route('admin.deletions'))->assertRedirect(route('login'));
    }

    public function test_a_member_and_a_moderator_are_forbidden(): void
    {
        $moderator = $this->staff(StaffRole::Moderator);
        $member = User::factory()->create();

        $this->actingAs($moderator)->get(route('admin.deletions'))->assertForbidden();
        $this->actingAs($member)->get(route('admin.deletions'))->assertForbidden();
    }

    public function test_an_admin_can_open_the_page(): void
    {
        $admin = $this->staff(StaffRole::Admin);

        $this->actingAs($admin)->get(route('admin.deletions'))
            ->assertOk()
            ->assertSee(__('admin_deletions.heading'));
    }

    public function test_the_empty_state_shows_when_nobody_is_waiting(): void
    {
        Livewire::actingAs($this->staff())->test(DeletionList::class)
            ->assertSee(__('admin_deletions.empty_title'));
    }

    public function test_it_lists_the_code_and_dates_but_no_personal_details(): void
    {
        $admin = $this->staff();
        $member = $this->waiting(10, ['name' => 'Zubayer Secretname', 'email' => 'secret.person@example.test']);
        $biodata = Biodata::factory()->approved()->forUser($member)->create();

        Livewire::actingAs($admin)->test(DeletionList::class)
            ->assertSee($biodata->public_code)
            ->assertSee(__('admin_deletions.days_left', ['days' => 10]))
            ->assertDontSee('Zubayer Secretname')
            ->assertDontSee('secret.person@example.test');
    }

    public function test_a_member_without_a_biodata_is_listed_with_a_note(): void
    {
        $this->waiting(5);

        Livewire::actingAs($this->staff())->test(DeletionList::class)
            ->assertSee(__('admin_deletions.no_biodata'));
    }

    public function test_cancelled_requests_staff_and_purged_accounts_are_not_listed(): void
    {
        $admin = $this->staff();

        $cancelled = User::factory()->create();
        $cancelledBiodata = Biodata::factory()->approved()->forUser($cancelled)->create();

        $staffMember = $this->staff(StaffRole::Moderator);
        $staffMember->forceFill(['deletion_requested_at' => now(), 'deletion_scheduled_for' => now()->addDays(3)])->save();
        $staffBiodata = Biodata::factory()->approved()->forUser($staffMember)->create();

        $purged = $this->waiting(-1);
        $purgedBiodata = Biodata::factory()->approved()->forUser($purged)->create();
        $purged->delete();

        Livewire::actingAs($admin)->test(DeletionList::class)
            ->assertDontSee($cancelledBiodata->public_code)
            ->assertDontSee($staffBiodata->public_code)
            ->assertDontSee($purgedBiodata->public_code);
    }

    public function test_the_soonest_date_comes_first(): void
    {
        $later = $this->waiting(12);
        $laterBiodata = Biodata::factory()->approved()->forUser($later)->create();
        $sooner = $this->waiting(2);
        $soonerBiodata = Biodata::factory()->approved()->forUser($sooner)->create();

        Livewire::actingAs($this->staff())->test(DeletionList::class)
            ->assertSeeInOrder([$soonerBiodata->public_code, $laterBiodata->public_code]);
    }

    public function test_an_open_report_shows_a_held_marker(): void
    {
        $member = $this->waiting(-1);
        $biodata = Biodata::factory()->approved()->forUser($member)->create();
        $this->openReport($biodata, 'list-report-1');

        Livewire::actingAs($this->staff())->test(DeletionList::class)
            ->assertSee(__('admin_deletions.paused.report'))
            ->assertDontSee(__('admin_deletions.due'));
    }

    public function test_an_unfinished_payment_shows_a_held_marker(): void
    {
        $member = $this->waiting(-1);
        Biodata::factory()->approved()->forUser($member)->create();
        Payment::factory()->status(PaymentStatus::UnderReview)->create(['user_id' => $member->id]);

        Livewire::actingAs($this->staff())->test(DeletionList::class)
            ->assertSee(__('admin_deletions.paused.payment'));
    }

    public function test_a_due_member_with_nothing_holding_it_shows_due(): void
    {
        $member = $this->waiting(-1);
        Biodata::factory()->approved()->forUser($member)->create();
        Payment::factory()->status(PaymentStatus::Paid)->create(['user_id' => $member->id]);

        Livewire::actingAs($this->staff())->test(DeletionList::class)
            ->assertSee(__('admin_deletions.due'))
            ->assertDontSee(__('admin_deletions.paused.payment'));
    }

    public function test_a_closed_report_does_not_hold_the_purge(): void
    {
        $member = $this->waiting(-1);
        $biodata = Biodata::factory()->approved()->forUser($member)->create();
        $this->openReport($biodata, 'list-report-2');
        DB::table('reports')->where('code', 'list-report-2')->update(['status' => 'resolved']);

        $this->assertSame([], app(DeletionPauseReasons::class)->for([$member->id]));
    }

    public function test_the_pause_service_checks_many_members_at_once(): void
    {
        $reported = $this->waiting(-1);
        $reportedBiodata = Biodata::factory()->approved()->forUser($reported)->create();
        $this->openReport($reportedBiodata, 'list-report-3');

        $paying = $this->waiting(-1);
        Payment::factory()->status(PaymentStatus::Pending)->create(['user_id' => $paying->id]);

        $both = $this->waiting(-1);
        $bothBiodata = Biodata::factory()->approved()->forUser($both)->create();
        $this->openReport($bothBiodata, 'list-report-4');
        Payment::factory()->status(PaymentStatus::UnderReview)->create(['user_id' => $both->id]);

        $free = $this->waiting(-1);

        $result = app(DeletionPauseReasons::class)->for([$reported->id, $paying->id, $both->id, $free->id]);

        $this->assertSame([DeletionPauseReasons::REPORT], $result[$reported->id]);
        $this->assertSame([DeletionPauseReasons::PAYMENT], $result[$paying->id]);
        $this->assertEqualsCanonicalizing([DeletionPauseReasons::REPORT, DeletionPauseReasons::PAYMENT], $result[$both->id]);
        $this->assertArrayNotHasKey($free->id, $result);
        $this->assertSame([], app(DeletionPauseReasons::class)->for([]));
    }

    public function test_the_list_only_reads_and_changes_nothing(): void
    {
        $member = $this->waiting(4);
        Biodata::factory()->approved()->forUser($member)->create();

        Livewire::actingAs($this->staff())->test(DeletionList::class);

        $fresh = User::query()->findOrFail($member->id);
        $this->assertNotNull($fresh->deletion_requested_at);
        $this->assertNotNull($fresh->deletion_scheduled_for);
    }

    public function test_the_menu_link_is_shown_to_admins_only(): void
    {
        $admin = $this->staff(StaffRole::Admin);

        $this->actingAs($admin)->get(route('admin.dashboard'))
            ->assertOk()
            ->assertSee(route('admin.deletions'), false);

        $moderator = $this->staff(StaffRole::Moderator);

        $this->actingAs($moderator)->get(route('admin.dashboard'))
            ->assertOk()
            ->assertDontSee(route('admin.deletions'), false);
    }
}
