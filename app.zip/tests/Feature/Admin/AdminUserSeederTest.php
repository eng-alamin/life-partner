<?php

declare(strict_types=1);

namespace Tests\Feature\Admin;

use App\Enums\StaffRole;
use App\Models\User;
use Database\Seeders\AdminUserSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use InvalidArgumentException;
use Spatie\Activitylog\Models\Activity;
use Tests\TestCase;

class AdminUserSeederTest extends TestCase
{
    use RefreshDatabase;

    private const PASSWORD = 'Long-Secret-Pass-77';

    /** @param  array<string, string>  $overrides */
    private function configure(array $overrides = []): void
    {
        config(['lifepartner.admin' => array_merge([
            'name' => 'Site Owner',
            'email' => 'Owner@Example.com',
            'password' => self::PASSWORD,
        ], $overrides)]);
    }

    private function assertRefused(): void
    {
        try {
            $this->seed(AdminUserSeeder::class);
            $this->fail('An InvalidArgumentException was expected.');
        } catch (InvalidArgumentException) {
            $this->assertTrue(true);
        }
    }

    public function test_it_creates_an_active_verified_admin_with_all_permissions(): void
    {
        $this->configure();

        $this->seed(AdminUserSeeder::class);

        $user = User::query()->where('email', 'owner@example.com')->firstOrFail();
        $this->assertSame('Site Owner', $user->name);
        $this->assertTrue($user->isActive());
        $this->assertNotNull($user->email_verified_at);
        $this->assertTrue($user->hasRole(StaffRole::Admin->value));
        $this->assertTrue($user->can('admin.access'));
        $this->assertTrue($user->can('users.manage'));
        $this->assertTrue($user->can('settings.manage'));
    }

    public function test_the_password_is_stored_hashed(): void
    {
        $this->configure();

        $this->seed(AdminUserSeeder::class);

        $stored = (string) User::query()->where('email', 'owner@example.com')->value('password');
        $this->assertNotSame(self::PASSWORD, $stored);
        $this->assertTrue(Hash::check(self::PASSWORD, $stored));
    }

    public function test_running_it_again_changes_nothing(): void
    {
        $this->configure();
        $this->seed(AdminUserSeeder::class);
        $before = (string) User::query()->where('email', 'owner@example.com')->value('password');

        $this->configure(['password' => 'Another-Long-Pass-99']);
        $this->seed(AdminUserSeeder::class);

        $this->assertSame(1, User::query()->count());
        $this->assertSame($before, (string) User::query()->where('email', 'owner@example.com')->value('password'));
        $this->assertSame(1, Activity::query()->where('description', 'staff.granted')->count());
    }

    public function test_an_existing_member_becomes_admin_and_keeps_the_password(): void
    {
        $member = User::factory()->create(['email' => 'owner@example.com']);
        $before = $member->password;
        $this->configure(['name' => '', 'password' => '']);

        $this->seed(AdminUserSeeder::class);

        $member->refresh();
        $this->assertTrue($member->hasRole(StaffRole::Admin->value));
        $this->assertSame($before, $member->password);
        $this->assertSame(1, User::query()->count());
    }

    public function test_an_existing_moderator_is_moved_to_admin(): void
    {
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);
        $user = User::factory()->create(['email' => 'owner@example.com']);
        $user->assignRole(StaffRole::Moderator->value);
        $this->configure();

        $this->seed(AdminUserSeeder::class);

        $user->refresh();
        $this->assertTrue($user->hasExactRoles([StaffRole::Admin->value]));
    }

    public function test_an_unverified_or_suspended_account_is_refused(): void
    {
        // The seeder stops before it creates the roles, so create them here for the role count below.
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);
        $this->configure();

        User::factory()->unverified()->create(['email' => 'owner@example.com']);
        $this->assertRefused();
        $this->assertSame(0, User::role(StaffRole::Admin->value)->count());

        User::query()->forceDelete();
        User::factory()->suspended()->create(['email' => 'owner@example.com']);
        $this->assertRefused();
    }

    public function test_a_missing_or_bad_email_stops_the_seeder(): void
    {
        $this->configure(['email' => '']);
        $this->assertRefused();

        $this->configure(['email' => 'not-an-email']);
        $this->assertRefused();

        $this->assertSame(0, User::query()->count());
    }

    public function test_a_missing_or_short_password_stops_the_seeder(): void
    {
        $this->configure(['password' => '']);
        $this->assertRefused();

        $this->configure(['password' => 'short-1']);
        $this->assertRefused();

        $this->assertSame(0, User::query()->count());
    }

    public function test_a_missing_name_stops_the_seeder(): void
    {
        $this->configure(['name' => ' ']);
        $this->assertRefused();

        $this->assertSame(0, User::query()->count());
    }

    public function test_the_log_holds_the_role_only(): void
    {
        $this->configure();

        $this->seed(AdminUserSeeder::class);

        $activity = Activity::query()->where('description', 'staff.granted')->latest('id')->firstOrFail();
        $json = (string) json_encode($activity->properties->all());

        $this->assertSame(['role' => 'admin'], $activity->properties->all());
        $this->assertStringNotContainsStringIgnoringCase('owner@example.com', $json);
        $this->assertStringNotContainsString(self::PASSWORD, $json);
    }

    public function test_db_seed_does_not_create_an_admin_by_itself(): void
    {
        $this->configure();

        $this->seed(\Database\Seeders\DatabaseSeeder::class);

        $this->assertSame(0, User::query()->where('email', 'owner@example.com')->count());
    }
}