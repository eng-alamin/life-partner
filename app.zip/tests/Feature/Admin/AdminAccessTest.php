<?php

declare(strict_types=1);

namespace Tests\Feature\Admin;

use App\Enums\BiodataStatus;
use App\Enums\StaffRole;
use App\Models\Biodata;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\CreatesStaff;
use Tests\TestCase;

class AdminAccessTest extends TestCase
{
    use CreatesStaff;
    use RefreshDatabase;

    public function test_guests_are_sent_to_login(): void
    {
        $this->get('/admin')->assertRedirect(route('login'));
        $this->get('/admin/approvals')->assertRedirect(route('login'));
    }

    public function test_a_normal_member_gets_403(): void
    {
        $biodata = Biodata::factory()->withStatus(BiodataStatus::Pending)->create();

        $this->actingAs(User::factory()->create());

        $this->get('/admin')->assertForbidden();
        $this->get('/admin/approvals')->assertForbidden();
        $this->get('/admin/approvals/'.$biodata->public_code)->assertForbidden();
    }

    public function test_an_admin_can_open_the_dashboard_and_the_queue(): void
    {
        $this->actingAs($this->staff());

        $this->get('/admin')->assertOk();
        $this->get('/admin/approvals')->assertOk();
    }

    public function test_a_moderator_can_open_the_queue(): void
    {
        $this->actingAs($this->staff(StaffRole::Moderator));

        $this->get('/admin/approvals')->assertOk();
    }

    public function test_a_suspended_staff_member_cannot_review(): void
    {
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);
        $staff = User::factory()->suspended()->create();
        $staff->assignRole(StaffRole::Admin->value);
        $biodata = Biodata::factory()->withStatus(BiodataStatus::Pending)->create();

        $this->assertFalse($staff->can('review', $biodata));
    }

    public function test_staff_cannot_review_their_own_biodata(): void
    {
        $staff = $this->staff();
        $own = Biodata::factory()->forUser($staff)->withStatus(BiodataStatus::Pending)->create();
        $other = Biodata::factory()->withStatus(BiodataStatus::Pending)->create();

        $this->assertFalse($staff->can('review', $own));
        $this->assertTrue($staff->can('review', $other));
    }
}
