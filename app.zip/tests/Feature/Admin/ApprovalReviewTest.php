<?php

declare(strict_types=1);

namespace Tests\Feature\Admin;

use App\Enums\BiodataStatus;
use App\Livewire\Admin\ApprovalReview;
use App\Models\Biodata;
use App\Models\Guardian;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\Concerns\CreatesStaff;
use Tests\TestCase;

class ApprovalReviewTest extends TestCase
{
    use CreatesStaff;
    use RefreshDatabase;

    private function pending(array $attributes = []): Biodata
    {
        return Biodata::factory()->withStatus(BiodataStatus::Pending)->create(array_merge([
            'submitted_at' => now(),
            'about_me' => 'I work as a teacher and enjoy quiet evenings with my family.',
        ], $attributes));
    }

    public function test_the_page_shows_the_profile_but_not_private_guardian_data(): void
    {
        $biodata = $this->pending();

        (new Guardian)->forceFill([
            'biodata_id' => $biodata->id,
            'name' => 'Hidden Guardian Name',
            'relation' => 'father',
            'phone' => '01711112222',
            'can_approve' => true,
        ])->save();

        $this->actingAs($this->staff());

        Livewire::test(ApprovalReview::class, ['biodata' => $biodata])
            ->assertSee($biodata->public_code)
            ->assertSee('I work as a teacher')
            ->assertDontSee('Hidden Guardian Name')
            ->assertDontSee('01711112222');
    }

    public function test_approving_moves_the_biodata_to_approved(): void
    {
        $biodata = $this->pending();
        $staff = $this->staff();
        $this->actingAs($staff);

        Livewire::test(ApprovalReview::class, ['biodata' => $biodata])
            ->call('approve')
            ->assertHasNoErrors()
            ->assertRedirect(route('admin.approvals'));

        $this->assertSame(BiodataStatus::Approved, $biodata->fresh()->status);
        $this->assertSame($staff->id, $biodata->fresh()->reviewed_by);
    }

    public function test_rejecting_needs_a_reason_of_at_least_ten_characters(): void
    {
        $biodata = $this->pending();
        $this->actingAs($this->staff());

        Livewire::test(ApprovalReview::class, ['biodata' => $biodata])
            ->set('rejectReason', 'short')
            ->call('reject')
            ->assertHasErrors(['rejectReason']);

        $this->assertSame(BiodataStatus::Pending, $biodata->fresh()->status);
    }

    public function test_rejecting_saves_the_reason_for_the_member(): void
    {
        $biodata = $this->pending();
        $this->actingAs($this->staff());

        Livewire::test(ApprovalReview::class, ['biodata' => $biodata])
            ->set('rejectReason', 'Please describe your family in a bit more detail.')
            ->call('reject')
            ->assertHasNoErrors()
            ->assertRedirect(route('admin.approvals'));

        $biodata->refresh();

        $this->assertSame(BiodataStatus::Rejected, $biodata->status);
        $this->assertSame('Please describe your family in a bit more detail.', $biodata->rejection_reason);
    }

    public function test_a_change_made_after_opening_blocks_the_decision(): void
    {
        $biodata = $this->pending();
        $this->actingAs($this->staff());

        $component = Livewire::test(ApprovalReview::class, ['biodata' => $biodata]);

        // The member edits the pending biodata while the reviewer has the page open.
        $biodata->forceFill(['revision' => 1])->save();

        $component->call('$refresh')
            ->assertSee(__('admin.review.stale'))
            ->call('approve')
            ->assertHasErrors(['form']);

        $this->assertSame(BiodataStatus::Pending, $biodata->fresh()->status);
    }

    public function test_a_decided_biodata_shows_no_decision_buttons(): void
    {
        $biodata = Biodata::factory()->withStatus(BiodataStatus::Approved)->create();
        $this->actingAs($this->staff());

        Livewire::test(ApprovalReview::class, ['biodata' => $biodata])
            ->assertSee(__('admin.review.not_pending'))
            ->assertDontSee(__('admin.review.decision'));
    }

    public function test_the_review_page_route_works_with_the_public_code(): void
    {
        $biodata = $this->pending();
        $this->actingAs($this->staff());

        $this->get('/admin/approvals/'.$biodata->public_code)->assertOk();
        $this->get('/admin/approvals/'.$biodata->id)->assertNotFound();
    }
}
