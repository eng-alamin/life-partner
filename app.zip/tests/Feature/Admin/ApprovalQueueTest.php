<?php

declare(strict_types=1);

namespace Tests\Feature\Admin;

use App\Enums\BiodataStatus;
use App\Livewire\Admin\ApprovalQueue;
use App\Models\Biodata;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\Concerns\CreatesStaff;
use Tests\TestCase;

class ApprovalQueueTest extends TestCase
{
    use CreatesStaff;
    use RefreshDatabase;

    public function test_it_lists_only_pending_biodatas(): void
    {
        $pending = Biodata::factory()->withStatus(BiodataStatus::Pending)->create(['submitted_at' => now()]);
        $approved = Biodata::factory()->withStatus(BiodataStatus::Approved)->create();
        $draft = Biodata::factory()->create();

        $this->actingAs($this->staff());

        Livewire::test(ApprovalQueue::class)
            ->assertSee($pending->public_code)
            ->assertDontSee($approved->public_code)
            ->assertDontSee($draft->public_code);
    }

    public function test_it_hides_the_reviewers_own_biodata(): void
    {
        $staff = $this->staff();
        $own = Biodata::factory()->forUser($staff)->withStatus(BiodataStatus::Pending)->create(['submitted_at' => now()]);

        $this->actingAs($staff);

        Livewire::test(ApprovalQueue::class)->assertDontSee($own->public_code);
    }

    public function test_the_oldest_submission_comes_first(): void
    {
        $newer = Biodata::factory()->withStatus(BiodataStatus::Pending)->create(['submitted_at' => now()->subHour()]);
        $older = Biodata::factory()->withStatus(BiodataStatus::Pending)->create(['submitted_at' => now()->subDay()]);

        $this->actingAs($this->staff());

        Livewire::test(ApprovalQueue::class)
            ->assertSeeInOrder([$older->public_code, $newer->public_code]);
    }

    public function test_an_empty_queue_shows_a_message(): void
    {
        $this->actingAs($this->staff());

        Livewire::test(ApprovalQueue::class)->assertSee(__('admin.queue.empty_title'));
    }
}
