<?php

declare(strict_types=1);

namespace Tests\Feature\Account;

use App\Enums\BiodataStatus;
use App\Enums\StaffRole;
use App\Models\Biodata;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Gate;
use Tests\Concerns\CreatesStaff;
use Tests\TestCase;

/**
 * While an account deletion is waiting, nothing may bring the biodata back into view by a side door.
 */
class DeletionBlocksBiodataChangesTest extends TestCase
{
    use CreatesStaff;
    use RefreshDatabase;

    private function markRequested(User $user): User
    {
        $user->forceFill([
            'deletion_requested_at' => now(),
            'deletion_scheduled_for' => now()->addDays(14),
        ])->save();

        return User::query()->findOrFail($user->id);
    }

    public function test_a_draft_can_be_edited_and_submitted_before_the_request(): void
    {
        $user = User::factory()->create();
        $draft = Biodata::factory()->withStatus(BiodataStatus::Draft)->forUser($user)->create();

        $this->assertTrue(Gate::forUser($user)->allows('update', $draft));
        $this->assertTrue(Gate::forUser($user)->allows('submit', $draft));
        $this->assertTrue(Gate::forUser($user)->allows('managePhotos', $draft));
    }

    public function test_a_draft_cannot_be_edited_submitted_or_given_photos_while_deletion_waits(): void
    {
        $user = User::factory()->create();
        $draft = Biodata::factory()->withStatus(BiodataStatus::Draft)->forUser($user)->create();
        $user = $this->markRequested($user);

        $this->assertTrue(Gate::forUser($user)->denies('update', $draft));
        $this->assertTrue(Gate::forUser($user)->denies('submit', $draft));
        $this->assertTrue(Gate::forUser($user)->denies('managePhotos', $draft));
    }

    public function test_a_rejected_biodata_cannot_be_sent_again_while_deletion_waits(): void
    {
        $user = User::factory()->create();
        $rejected = Biodata::factory()->withStatus(BiodataStatus::Rejected)->forUser($user)->create();
        $user = $this->markRequested($user);

        $this->assertTrue(Gate::forUser($user)->denies('submit', $rejected));
    }

    public function test_a_member_cannot_create_a_biodata_while_deletion_waits(): void
    {
        $user = User::factory()->create();

        $this->assertTrue(Gate::forUser($user)->allows('create', Biodata::class));

        $user = $this->markRequested($user);

        $this->assertTrue(Gate::forUser($user)->denies('create', Biodata::class));
    }

    public function test_a_deactivated_biodata_cannot_be_reactivated_while_deletion_waits(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->forUser($user)->create([
            'status' => BiodataStatus::Deactivated->value,
            'hidden_source' => 'owner',
            'hidden_from' => 'approved',
            'hidden_revision' => 0,
            'revision' => 0,
            'deactivated_at' => now(),
        ]);

        $this->assertTrue(Gate::forUser($user)->allows('reactivate', $biodata));

        $user = $this->markRequested($user);

        $this->assertTrue(Gate::forUser($user)->denies('reactivate', $biodata));
    }

    public function test_a_biodata_the_member_hid_cannot_be_shown_again_while_deletion_waits(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->forUser($user)->create([
            'status' => BiodataStatus::Hidden->value,
            'hidden_source' => 'owner',
            'hidden_from' => 'approved',
            'hidden_revision' => 0,
            'revision' => 0,
            'hidden_at' => now(),
        ]);

        $this->assertTrue(Gate::forUser($user)->allows('unhide', $biodata));

        $user = $this->markRequested($user);

        $this->assertTrue(Gate::forUser($user)->denies('unhide', $biodata));
    }

    public function test_staff_cannot_restore_the_biodata_of_a_member_whose_deletion_waits(): void
    {
        $staff = $this->staff(StaffRole::Moderator);

        $waiting = User::factory()->create();
        $waitingBiodata = Biodata::factory()->forUser($waiting)->create([
            'status' => BiodataStatus::Hidden->value,
            'hidden_source' => 'staff',
            'hidden_from' => 'approved',
            'hidden_revision' => 0,
            'revision' => 0,
            'hidden_at' => now(),
        ]);
        $this->markRequested($waiting);

        $normalBiodata = Biodata::factory()->create([
            'status' => BiodataStatus::Hidden->value,
            'hidden_source' => 'staff',
            'hidden_from' => 'approved',
            'hidden_revision' => 0,
            'revision' => 0,
            'hidden_at' => now(),
        ]);

        $this->assertTrue(Gate::forUser($staff)->denies('restoreHidden', $waitingBiodata));
        $this->assertTrue(Gate::forUser($staff)->allows('restoreHidden', $normalBiodata));
    }
}
