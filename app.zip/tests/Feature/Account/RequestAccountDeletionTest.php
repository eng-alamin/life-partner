<?php

declare(strict_types=1);

namespace Tests\Feature\Account;

use App\Actions\Account\RequestAccountDeletion;
use App\Enums\BiodataStatus;
use App\Enums\HiddenSource;
use App\Enums\InterestActor;
use App\Enums\InterestStatus;
use App\Enums\StaffRole;
use App\Models\Biodata;
use App\Models\Interest;
use App\Models\InterestStatusHistory;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use Spatie\Activitylog\Models\Activity;
use Tests\Concerns\CreatesStaff;
use Tests\TestCase;

class RequestAccountDeletionTest extends TestCase
{
    use CreatesStaff;
    use RefreshDatabase;

    private function request(User $user, string $proof = 'password'): User
    {
        return app(RequestAccountDeletion::class)($user, $proof);
    }

    public function test_the_right_password_saves_the_request_and_a_date_fourteen_days_away(): void
    {
        $user = User::factory()->create();

        $this->request($user);

        $saved = User::query()->findOrFail($user->id);
        $this->assertTrue($saved->hasDeletionRequested());
        $this->assertTrue($saved->deletion_scheduled_for->between(now()->addDays(14)->subMinute(), now()->addDays(14)->addMinute()));
        $this->assertSame(14, RequestAccountDeletion::WAIT_DAYS);
    }

    public function test_a_wrong_password_is_refused_and_nothing_changes(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create();

        try {
            $this->request($user, 'not-my-password');
            $this->fail('A wrong password must be refused.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('proof', $e->errors());
        }

        $this->assertFalse(User::query()->findOrFail($user->id)->hasDeletionRequested());
        $this->assertSame(BiodataStatus::Approved, Biodata::query()->findOrFail($biodata->id)->status);
    }

    public function test_an_approved_biodata_is_deactivated_and_leaves_search(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create(['revision' => 3]);

        $this->request($user);

        $saved = Biodata::query()->findOrFail($biodata->id);
        $this->assertSame(BiodataStatus::Deactivated, $saved->status);
        $this->assertSame(HiddenSource::Owner, $saved->hidden_source);
        $this->assertSame('approved', $saved->hidden_from);
        $this->assertNull($saved->deactivation_reason);
        $this->assertFalse(Biodata::query()->searchable()->whereKey($biodata->id)->exists());
    }

    public function test_a_pending_biodata_and_a_biodata_the_member_hid_are_deactivated_too(): void
    {
        $pendingUser = User::factory()->create();
        $pending = Biodata::factory()->withStatus(BiodataStatus::Pending)->forUser($pendingUser)->create(['submitted_at' => now()]);

        $hiddenUser = User::factory()->create();
        $hidden = Biodata::factory()->approved()->forUser($hiddenUser)->create();
        app(\App\Actions\Biodata\HideBiodata::class)($hiddenUser);

        $this->request($pendingUser);
        $this->request($hiddenUser);

        $this->assertSame(BiodataStatus::Deactivated, Biodata::query()->findOrFail($pending->id)->status);
        $savedHidden = Biodata::query()->findOrFail($hidden->id);
        $this->assertSame(BiodataStatus::Deactivated, $savedHidden->status);
        $this->assertSame('approved', $savedHidden->hidden_from);
    }

    public function test_a_draft_a_rejected_and_a_staff_hidden_biodata_are_left_as_they_are(): void
    {
        foreach ([BiodataStatus::Draft, BiodataStatus::Rejected] as $status) {
            $user = User::factory()->create();
            $biodata = Biodata::factory()->withStatus($status)->forUser($user)->create();

            $this->request($user);

            $this->assertSame($status, Biodata::query()->findOrFail($biodata->id)->status);
        }

        $user = User::factory()->create();
        $staffHidden = Biodata::factory()->forUser($user)->create([
            'status' => BiodataStatus::Hidden->value,
            'hidden_source' => HiddenSource::Staff->value,
            'hidden_from' => 'approved',
            'hidden_at' => now(),
        ]);

        $this->request($user);

        $saved = Biodata::query()->findOrFail($staffHidden->id);
        $this->assertSame(BiodataStatus::Hidden, $saved->status);
        $this->assertSame(HiddenSource::Staff, $saved->hidden_source);
    }

    public function test_a_member_without_a_biodata_can_ask_too(): void
    {
        $user = User::factory()->create();

        $this->request($user);

        $this->assertTrue(User::query()->findOrFail($user->id)->hasDeletionRequested());
    }

    public function test_pending_interests_are_cancelled_by_the_system_and_accepted_ones_are_kept(): void
    {
        $user = User::factory()->create();
        $mine = Biodata::factory()->approved()->forUser($user)->create();
        $a = Biodata::factory()->approved()->create();
        $b = Biodata::factory()->approved()->create();
        $c = Biodata::factory()->approved()->create();

        $received = Interest::factory()->between($a, $mine)->create();
        $sent = Interest::factory()->between($mine, $b)->create();
        $accepted = Interest::factory()->between($mine, $c)->accepted()->create();

        $this->request($user);

        foreach ([$received, $sent] as $interest) {
            $this->assertSame(InterestStatus::Cancelled, Interest::query()->findOrFail($interest->id)->status);

            $history = InterestStatusHistory::query()->where('interest_id', $interest->id)->latest('id')->firstOrFail();
            $this->assertSame(InterestActor::System, $history->actor_type);
        }

        $this->assertSame(InterestStatus::Accepted, Interest::query()->findOrFail($accepted->id)->status);
    }

    public function test_asking_twice_is_refused(): void
    {
        $user = User::factory()->create();
        $this->request($user);

        try {
            $this->request($user);
            $this->fail('A second request must be refused.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('form', $e->errors());
        }
    }

    public function test_a_staff_account_cannot_delete_itself(): void
    {
        $staff = $this->staff(StaffRole::Moderator);

        try {
            $this->request($staff);
            $this->fail('A staff account must be refused.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('form', $e->errors());
        }

        $this->assertFalse(User::query()->findOrFail($staff->id)->hasDeletionRequested());
    }

    public function test_an_account_without_a_password_confirms_with_its_email_in_any_letter_case(): void
    {
        $user = User::factory()->create(['email' => 'Social.Member@example.com', 'password' => null]);

        try {
            $this->request($user, 'someone.else@example.com');
            $this->fail('A different email must be refused.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('proof', $e->errors());
        }

        $this->assertFalse(User::query()->findOrFail($user->id)->hasDeletionRequested());

        $this->request($user, '  social.member@EXAMPLE.com ');

        $this->assertTrue(User::query()->findOrFail($user->id)->hasDeletionRequested());
    }

    public function test_an_empty_proof_is_refused_for_both_kinds_of_account(): void
    {
        foreach ([User::factory()->create(), User::factory()->create(['password' => null])] as $user) {
            try {
                $this->request($user, '');
                $this->fail('An empty proof must be refused.');
            } catch (ValidationException $e) {
                $this->assertArrayHasKey('proof', $e->errors());
            }
        }
    }

    public function test_the_activity_log_holds_the_action_name_only(): void
    {
        $user = User::factory()->create(['email' => 'log.check@example.com']);
        Biodata::factory()->approved()->forUser($user)->create(['about_me' => 'A private sentence about me.']);

        $this->request($user, 'password');

        $entry = Activity::query()->where('log_name', 'account')->latest('id')->firstOrFail();
        $this->assertSame('account.deletion_requested', $entry->description);
        $this->assertSame(['action' => 'deletion_requested'], $entry->properties->toArray());

        $dump = json_encode($entry->toArray(), JSON_UNESCAPED_UNICODE);
        $this->assertStringNotContainsString('log.check@example.com', (string) $dump);
        $this->assertStringNotContainsString('A private sentence', (string) $dump);
    }
}
