<?php

declare(strict_types=1);

namespace Tests\Feature\Account;

use App\Actions\Account\CancelAccountDeletion;
use App\Actions\Account\RequestAccountDeletion;
use App\Actions\Biodata\ReactivateBiodata;
use App\Enums\BiodataStatus;
use App\Models\Biodata;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use Spatie\Activitylog\Models\Activity;
use Tests\TestCase;

class CancelAccountDeletionTest extends TestCase
{
    use RefreshDatabase;

    private function requested(User $user): void
    {
        app(RequestAccountDeletion::class)($user, 'password');
    }

    public function test_cancelling_clears_the_request(): void
    {
        $user = User::factory()->create();
        $this->requested($user);

        app(CancelAccountDeletion::class)($user);

        $saved = User::query()->findOrFail($user->id);
        $this->assertFalse($saved->hasDeletionRequested());
        $this->assertNull($saved->deletion_scheduled_for);
    }

    public function test_the_biodata_stays_deactivated_after_cancelling(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create();
        $this->requested($user);

        app(CancelAccountDeletion::class)($user);

        $this->assertSame(BiodataStatus::Deactivated, Biodata::query()->findOrFail($biodata->id)->status);
        $this->assertFalse(Biodata::query()->searchable()->whereKey($biodata->id)->exists());
    }

    public function test_the_member_can_reactivate_after_cancelling_and_not_before(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create();
        $this->requested($user);

        $this->assertTrue(User::query()->findOrFail($user->id)->hasDeletionRequested());
        $this->assertFalse(\Illuminate\Support\Facades\Gate::forUser(User::query()->findOrFail($user->id))->allows('reactivate', Biodata::query()->findOrFail($biodata->id)));

        app(CancelAccountDeletion::class)($user);

        $status = app(ReactivateBiodata::class)(User::query()->findOrFail($user->id));

        $this->assertSame(BiodataStatus::Approved, $status);
        $this->assertSame(BiodataStatus::Approved, Biodata::query()->findOrFail($biodata->id)->status);
    }

    public function test_cancelling_without_a_request_is_refused(): void
    {
        $user = User::factory()->create();

        try {
            app(CancelAccountDeletion::class)($user);
            $this->fail('There is nothing to cancel.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('form', $e->errors());
        }
    }

    public function test_the_member_can_ask_again_after_cancelling(): void
    {
        $user = User::factory()->create();
        $this->requested($user);
        app(CancelAccountDeletion::class)($user);

        $this->requested($user);

        $this->assertTrue(User::query()->findOrFail($user->id)->hasDeletionRequested());
    }

    public function test_cancelling_only_touches_the_signed_in_member(): void
    {
        $mine = User::factory()->create();
        $other = User::factory()->create();
        $this->requested($mine);
        $this->requested($other);

        app(CancelAccountDeletion::class)($mine);

        $this->assertFalse(User::query()->findOrFail($mine->id)->hasDeletionRequested());
        $this->assertTrue(User::query()->findOrFail($other->id)->hasDeletionRequested());
    }

    public function test_the_log_holds_the_action_name_only(): void
    {
        $user = User::factory()->create();
        $this->requested($user);

        app(CancelAccountDeletion::class)($user);

        $entry = Activity::query()->where('log_name', 'account')->latest('id')->firstOrFail();
        $this->assertSame('account.deletion_cancelled', $entry->description);
        $this->assertSame(['action' => 'deletion_cancelled'], $entry->properties->toArray());
    }
}
