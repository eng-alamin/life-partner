<?php

declare(strict_types=1);

namespace Tests\Feature\Account;

use App\Actions\Account\PurgeDeletedAccount;
use App\Actions\Account\PurgeDeletedAccounts;
use App\Actions\Account\RequestAccountDeletion;
use App\Enums\BiodataStatus;
use App\Enums\InterestStatus;
use App\Enums\PaymentStatus;
use App\Models\Biodata;
use App\Models\Interest;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\Models\Activity;
use Tests\TestCase;

class PurgeDeletedAccountTest extends TestCase
{
    use RefreshDatabase;

    /** A member whose 14-day wait is already over. */
    private function due(?User $user = null): User
    {
        $user ??= User::factory()->create();
        app(RequestAccountDeletion::class)($user, 'password');

        User::query()->whereKey($user->id)->update(['deletion_scheduled_for' => now()->subMinute()]);

        return User::query()->findOrFail($user->id);
    }

    private function purge(User $user): string
    {
        return app(PurgeDeletedAccount::class)($user->id);
    }

    public function test_a_request_still_waiting_is_not_purged(): void
    {
        $user = User::factory()->create();
        app(RequestAccountDeletion::class)($user, 'password');

        $this->assertSame(PurgeDeletedAccount::SKIPPED, $this->purge($user));
        $this->assertSame($user->email, User::query()->findOrFail($user->id)->email);
    }

    public function test_a_cancelled_request_is_not_purged(): void
    {
        $user = $this->due();
        User::query()->whereKey($user->id)->update(['deletion_requested_at' => null, 'deletion_scheduled_for' => null]);

        $this->assertSame(PurgeDeletedAccount::SKIPPED, $this->purge($user));
        $this->assertNull(User::query()->findOrFail($user->id)->deleted_at);
    }

    public function test_an_account_without_a_request_is_not_purged(): void
    {
        $user = User::factory()->create();

        $this->assertSame(PurgeDeletedAccount::SKIPPED, $this->purge($user));
    }

    public function test_the_user_row_is_anonymised_and_soft_deleted(): void
    {
        $user = User::factory()->withVerifiedPhone()->create(['email' => 'real@example.com', 'name' => 'Real Name']);
        $user = $this->due($user);

        $this->assertSame(PurgeDeletedAccount::PURGED, $this->purge($user));

        $this->assertNull(User::query()->find($user->id));
        $row = User::withTrashed()->findOrFail($user->id);
        $this->assertNotNull($row->deleted_at);
        $this->assertSame('Deleted member', $row->name);
        $this->assertSame('deleted-'.$user->id.'@deleted.invalid', $row->email);
        $this->assertNull($row->phone);
        $this->assertNull($row->phone_hash);
        $this->assertNull($row->email_verified_at);
        $this->assertFalse(\Illuminate\Support\Facades\Hash::check('password', (string) $row->password));
    }

    public function test_the_old_email_can_be_used_again_after_the_purge(): void
    {
        $user = $this->due(User::factory()->create(['email' => 'again@example.com']));
        $this->purge($user);

        $this->assertNotNull(User::factory()->create(['email' => 'again@example.com']));
    }

    public function test_the_biodata_row_stays_but_every_personal_field_is_emptied(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create(['about_me' => 'private text', 'profession' => 'Teacher']);
        $user = $this->due($user);

        $this->purge($user);

        $saved = Biodata::query()->findOrFail($biodata->id);
        $this->assertNull($saved->deleted_at);
        $this->assertSame(BiodataStatus::Deactivated, $saved->status);
        $this->assertNull($saved->about_me);
        $this->assertNull($saved->profession);
        $this->assertNull($saved->birth_date);
        $this->assertNull($saved->height_cm);
        $this->assertSame($biodata->public_code, $saved->public_code);
        $this->assertFalse(Biodata::query()->searchable()->whereKey($biodata->id)->exists());
    }

    public function test_photos_education_and_guardian_are_deleted_with_their_files(): void
    {
        Storage::fake('photos');
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create();

        Storage::disk('photos')->put('a/main.jpg', 'x');
        Storage::disk('photos')->put('a/thumb.jpg', 'x');
        DB::table('biodata_photos')->insert([
            'biodata_id' => $biodata->id, 'code' => 'photo-code-1', 'path' => 'a/main.jpg',
            'thumb_path' => 'a/thumb.jpg', 'is_main' => true, 'status' => 'approved',
            'created_at' => now(), 'updated_at' => now(),
        ]);
        DB::table('biodata_educations')->insert([
            'biodata_id' => $biodata->id, 'degree' => 'BSc', 'institution' => 'Uni', 'passing_year' => 2015,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $guardian = new \App\Models\Guardian(['name' => 'G', 'relation' => 'father', 'phone' => '01711111111']);
        $guardian->biodata_id = $biodata->id;
        $guardian->save();

        $this->purge($this->due($user));

        $this->assertSame(0, DB::table('biodata_photos')->where('biodata_id', $biodata->id)->count());
        $this->assertSame(0, DB::table('biodata_educations')->where('biodata_id', $biodata->id)->count());
        $this->assertSame(0, DB::table('guardians')->where('biodata_id', $biodata->id)->count());
        Storage::disk('photos')->assertMissing('a/main.jpg');
        Storage::disk('photos')->assertMissing('a/thumb.jpg');
    }

    public function test_lists_blocks_and_notifications_are_deleted_in_both_directions(): void
    {
        $user = User::factory()->create();
        $other = User::factory()->create();
        $mine = Biodata::factory()->approved()->forUser($user)->create();
        $theirs = Biodata::factory()->approved()->forUser($other)->create();

        DB::table('shortlists')->insert([
            ['user_id' => $user->id, 'biodata_id' => $theirs->id, 'created_at' => now()],
            ['user_id' => $other->id, 'biodata_id' => $mine->id, 'created_at' => now()],
        ]);
        DB::table('blocks')->insert([
            ['blocker_user_id' => $user->id, 'blocked_user_id' => $other->id, 'created_at' => now()],
            ['blocker_user_id' => $other->id, 'blocked_user_id' => $user->id, 'created_at' => now()],
        ]);
        DB::table('notifications')->insert([
            'id' => (string) \Illuminate\Support\Str::uuid(), 'type' => 'x', 'notifiable_type' => User::class,
            'notifiable_id' => $user->id, 'data' => '{}', 'created_at' => now(), 'updated_at' => now(),
        ]);

        $this->purge($this->due($user));

        $this->assertSame(0, DB::table('shortlists')->count());
        $this->assertSame(0, DB::table('blocks')->count());
        $this->assertSame(0, DB::table('notifications')->where('notifiable_id', $user->id)->count());
    }

    public function test_interests_are_kept_with_status_and_dates_but_no_message(): void
    {
        $user = User::factory()->create();
        $other = User::factory()->create();
        $mine = Biodata::factory()->approved()->forUser($user)->create();
        $theirs = Biodata::factory()->approved()->forUser($other)->create();
        $interest = Interest::factory()->between($theirs, $mine)->accepted()->create();
        DB::table('interests')->where('id', $interest->id)->update(['message' => 'hello private']);

        $this->purge($this->due($user));

        $row = DB::table('interests')->where('id', $interest->id)->first();
        $this->assertNotNull($row);
        $this->assertSame(InterestStatus::Accepted->value, $row->status);
        $this->assertNull($row->message);
        $this->assertNull($row->guardian_token_hash);
    }

    public function test_payments_are_kept_but_payer_number_and_screenshot_are_removed(): void
    {
        Storage::fake('payment_proofs');
        $user = User::factory()->create();
        Storage::disk('payment_proofs')->put('p/proof.jpg', 'x');
        $payment = Payment::factory()->status(PaymentStatus::Paid)->create(['user_id' => $user->id]);
        DB::table('payments')->where('id', $payment->id)->update(['payer_number' => '01711111111', 'proof_path' => 'p/proof.jpg']);

        $this->purge($this->due($user));

        $row = DB::table('payments')->where('id', $payment->id)->first();
        $this->assertNotNull($row);
        $this->assertSame($user->id, (int) $row->user_id);
        $this->assertSame(50000, (int) $row->amount_minor);
        $this->assertNull($row->payer_number);
        $this->assertNull($row->proof_path);
        Storage::disk('payment_proofs')->assertMissing('p/proof.jpg');
    }

    public function test_an_unfinished_payment_pauses_the_purge(): void
    {
        $user = User::factory()->create();
        Payment::factory()->status(PaymentStatus::UnderReview)->create(['user_id' => $user->id]);
        $user = $this->due($user);

        $this->assertSame(PurgeDeletedAccount::PAUSED_PAYMENT, $this->purge($user));
        $this->assertSame($user->email, User::query()->findOrFail($user->id)->email);
    }

    public function test_an_open_report_against_the_biodata_pauses_the_purge(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create();
        $reporter = User::factory()->create();
        DB::table('reports')->insert([
            'code' => 'report-code-1', 'reporter_user_id' => $reporter->id, 'biodata_id' => $biodata->id,
            'reported_code' => $biodata->public_code, 'reason' => 'fake', 'status' => 'open',
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $user = $this->due($user);

        $this->assertSame(PurgeDeletedAccount::PAUSED_REPORT, $this->purge($user));
        $this->assertNotNull(User::query()->find($user->id));
    }

    public function test_a_paused_purge_goes_ahead_once_the_report_is_closed(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create();
        DB::table('reports')->insert([
            'code' => 'report-code-2', 'reporter_user_id' => User::factory()->create()->id, 'biodata_id' => $biodata->id,
            'reported_code' => $biodata->public_code, 'reason' => 'fake', 'status' => 'open',
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $user = $this->due($user);
        $this->purge($user);

        DB::table('reports')->where('code', 'report-code-2')->update(['status' => 'resolved']);

        $this->assertSame(PurgeDeletedAccount::PURGED, $this->purge($user));
    }

    public function test_accounting_rows_are_never_removed(): void
    {
        $user = User::factory()->create();
        DB::table('credit_ledger')->insert(['user_id' => $user->id, 'delta' => 10, 'reason' => 'purchase', 'created_at' => now()]);
        Payment::factory()->status(PaymentStatus::Paid)->create(['user_id' => $user->id]);

        $this->purge($this->due($user));

        $this->assertSame(1, DB::table('credit_ledger')->where('user_id', $user->id)->count());
        $this->assertSame(1, DB::table('payments')->where('user_id', $user->id)->count());
    }

    public function test_the_log_has_the_action_name_only(): void
    {
        $user = User::factory()->create(['email' => 'secret@example.com']);
        $this->purge($this->due($user));

        $log = Activity::query()->where('description', 'account.purged')->firstOrFail();
        $this->assertSame(['action' => 'purged'], $log->properties->toArray());
        $this->assertStringNotContainsString('secret@example.com', json_encode($log->toArray(), JSON_THROW_ON_ERROR));
    }

    public function test_a_second_run_does_nothing(): void
    {
        $user = $this->due();
        $this->assertSame(PurgeDeletedAccount::PURGED, $this->purge($user));
        $this->assertSame(PurgeDeletedAccount::SKIPPED, $this->purge($user));
    }

    public function test_the_batch_purges_only_due_accounts(): void
    {
        $due = $this->due();
        $waiting = User::factory()->create();
        app(RequestAccountDeletion::class)($waiting, 'password');
        $plain = User::factory()->create();

        $counts = app(PurgeDeletedAccounts::class)();

        $this->assertSame(1, $counts['purged']);
        $this->assertNull(User::query()->find($due->id));
        $this->assertNotNull(User::query()->find($waiting->id));
        $this->assertNotNull(User::query()->find($plain->id));
    }

    public function test_the_command_runs_and_reports(): void
    {
        $this->due();

        $this->artisan('accounts:purge-deleted')
            ->expectsOutputToContain('Purged 1')
            ->assertSuccessful();
    }
}
