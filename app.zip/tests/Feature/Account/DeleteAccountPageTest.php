<?php

declare(strict_types=1);

namespace Tests\Feature\Account;

use App\Enums\BiodataStatus;
use App\Enums\StaffRole;
use App\Livewire\Account\DeleteAccount;
use App\Livewire\Biodata\MyBiodata;
use App\Models\Biodata;
use App\Models\User;
use App\Support\Digits;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\Concerns\CreatesStaff;
use Tests\TestCase;

class DeleteAccountPageTest extends TestCase
{
    use CreatesStaff;
    use RefreshDatabase;

    public function test_a_guest_is_sent_to_the_login_page(): void
    {
        $this->get(route('account.delete'))->assertRedirect(route('login'));
    }

    public function test_a_member_can_open_the_page(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->get(route('account.delete'))
            ->assertOk()
            ->assertSee(__('account_deletion.start'));
    }

    public function test_the_member_asks_with_the_right_password(): void
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->forUser($user)->create();

        Livewire::actingAs($user)->test(DeleteAccount::class)
            ->assertSee(__('account_deletion.start'))
            ->call('startConfirm')
            ->assertSee(__('account_deletion.proof.password_label'))
            ->set('proof', 'password')
            ->call('requestDeletion')
            ->assertRedirect(route('account.delete'));

        $this->assertTrue(User::query()->findOrFail($user->id)->hasDeletionRequested());
        $this->assertSame(BiodataStatus::Deactivated, Biodata::query()->findOrFail($biodata->id)->status);
    }

    public function test_a_wrong_password_shows_an_error_and_changes_nothing(): void
    {
        $user = User::factory()->create();

        Livewire::actingAs($user)->test(DeleteAccount::class)
            ->call('startConfirm')
            ->set('proof', 'wrong-password')
            ->call('requestDeletion')
            ->assertHasErrors('proof');

        $this->assertFalse(User::query()->findOrFail($user->id)->hasDeletionRequested());
    }

    public function test_an_account_without_a_password_is_asked_for_its_email(): void
    {
        $user = User::factory()->create(['email' => 'no.password@example.com', 'password' => null]);

        Livewire::actingAs($user)->test(DeleteAccount::class)
            ->call('startConfirm')
            ->assertSee(__('account_deletion.proof.email_label'))
            ->set('proof', 'no.password@example.com')
            ->call('requestDeletion')
            ->assertRedirect(route('account.delete'));

        $this->assertTrue(User::query()->findOrFail($user->id)->hasDeletionRequested());
    }

    public function test_going_back_closes_the_form_and_clears_the_typed_value(): void
    {
        $user = User::factory()->create();

        Livewire::actingAs($user)->test(DeleteAccount::class)
            ->call('startConfirm')
            ->set('proof', 'something')
            ->call('stopConfirm')
            ->assertSet('confirming', false)
            ->assertSet('proof', '');
    }

    public function test_a_waiting_request_shows_the_date_and_the_cancel_button(): void
    {
        $user = User::factory()->create();
        $user->forceFill(['deletion_requested_at' => now(), 'deletion_scheduled_for' => now()->addDays(14)])->save();
        $saved = User::query()->findOrFail($user->id);
        $date = Digits::localize($saved->deletion_scheduled_for->translatedFormat('j M Y'));

        Livewire::actingAs($saved)->test(DeleteAccount::class)
            ->assertSee(__('account_deletion.requested.text', ['date' => $date]))
            ->assertSee(__('account_deletion.requested.cancel_button'))
            ->assertDontSee(__('account_deletion.start'));
    }

    public function test_cancelling_from_the_page_goes_back_to_my_biodata(): void
    {
        $user = User::factory()->create();
        $user->forceFill(['deletion_requested_at' => now(), 'deletion_scheduled_for' => now()->addDays(14)])->save();

        Livewire::actingAs(User::query()->findOrFail($user->id))->test(DeleteAccount::class)
            ->call('cancelDeletion')
            ->assertRedirect(route('my-biodata'));

        $this->assertFalse(User::query()->findOrFail($user->id)->hasDeletionRequested());
    }

    public function test_a_staff_account_sees_the_staff_notice_and_no_start_button(): void
    {
        $staff = $this->staff(StaffRole::Moderator);

        Livewire::actingAs($staff)->test(DeleteAccount::class)
            ->assertSee(__('account_deletion.staff'))
            ->assertDontSee(__('account_deletion.start'));
    }

    public function test_too_many_wrong_attempts_are_stopped(): void
    {
        $user = User::factory()->create();

        $component = Livewire::actingAs($user)->test(DeleteAccount::class)->call('startConfirm');

        foreach (range(1, 5) as $ignored) {
            $component->set('proof', 'wrong')->call('requestDeletion')->assertHasErrors('proof');
        }

        $component->set('proof', 'password')->call('requestDeletion')->assertHasErrors('form');

        $this->assertFalse(User::query()->findOrFail($user->id)->hasDeletionRequested());
    }

    public function test_my_biodata_links_to_the_page(): void
    {
        $user = User::factory()->create();

        Livewire::actingAs($user)->test(MyBiodata::class)
            ->assertSee(__('account_deletion.link'));
    }
}
