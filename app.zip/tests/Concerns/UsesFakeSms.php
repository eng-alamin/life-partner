<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Services\Sms\SmsGateway;

/** Puts a FakeSmsGateway in place of the real one for the current test. */
trait UsesFakeSms
{
    protected function fakeSms(bool $ready = true): FakeSmsGateway
    {
        $gateway = new FakeSmsGateway;
        $gateway->ready = $ready;

        $this->app->instance(SmsGateway::class, $gateway);

        return $gateway;
    }
}
