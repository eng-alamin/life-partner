<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Enums\StaffRole;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;

trait CreatesStaff
{
    /** An active, verified account holding the given staff role. */
    protected function staff(StaffRole $role = StaffRole::Admin): User
    {
        $this->seed(RolesAndPermissionsSeeder::class);

        $user = User::factory()->create();
        $user->assignRole($role->value);

        return $user;
    }
}
