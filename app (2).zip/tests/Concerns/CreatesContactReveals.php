<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Enums\BiodataStatus;
use App\Enums\BiodataType;
use App\Enums\GuardianApprovalStatus;
use App\Enums\GuardianRelation;
use App\Models\Biodata;
use App\Models\Guardian;
use App\Models\Interest;
use App\Models\User;

/** Shared set-up for the contact reveal tests (includes CreatesInterests). */
trait CreatesContactReveals
{
    use CreatesInterests;

    protected function guardianFor(Biodata $biodata, string $name, string $phone, GuardianRelation $relation = GuardianRelation::Father): Guardian
    {
        $guardian = new Guardian;
        $guardian->forceFill([
            'biodata_id' => $biodata->getKey(),
            'name' => $name,
            'relation' => $relation->value,
            'phone' => $phone,
            'can_approve' => true,
        ])->save();

        return $guardian;
    }

    /**
     * An accepted interest between a groom and a bride. Each side has a guardian
     * with a different name and phone, so a test can tell whose details it sees.
     *
     * @return array{0: User, 1: User, 2: Interest, 3: Biodata, 4: Biodata} groom user, bride user, interest, groom biodata, bride biodata
     */
    protected function connectedPair(GuardianApprovalStatus $guardianStatus = GuardianApprovalStatus::NotRequired): array
    {
        [$groomUser, $groom] = $this->member(BiodataType::Groom, ['employer' => 'Secret Corp Ltd']);
        [$brideUser, $bride] = $this->member(BiodataType::Bride);
        $this->guardianFor($groom, 'Groom Guardian Karim', '01711111111', GuardianRelation::Father);
        $this->guardianFor($bride, 'Bride Guardian Rahim', '01822222222', GuardianRelation::Mother);

        $interest = Interest::factory()->between($groom, $bride)->accepted()->create();
        $interest->forceFill(['guardian_status' => $guardianStatus->value])->save();

        return [$groomUser, $brideUser, $interest->fresh(), $groom, $bride];
    }

    protected function setBiodataStatus(Biodata $biodata, BiodataStatus $status): void
    {
        $biodata->forceFill(['status' => $status->value])->save();
    }
}
