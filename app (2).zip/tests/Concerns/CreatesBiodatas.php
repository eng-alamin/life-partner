<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Enums\BiodataType;
use App\Models\Biodata;
use App\Models\User;

trait CreatesBiodatas
{
    /** An approved biodata owned by a new member. */
    protected function approvedBiodata(BiodataType $type = BiodataType::Bride, array $attributes = []): Biodata
    {
        return Biodata::factory()->approved()->ofType($type)->create($attributes);
    }

    /** A verified, active member who has started a biodata of the given type (searching needs one). */
    protected function memberLookingFor(BiodataType $wanted): User
    {
        $user = User::factory()->create();
        Biodata::factory()->forUser($user)->ofType($wanted->opposite())->create();

        return $user;
    }
}
