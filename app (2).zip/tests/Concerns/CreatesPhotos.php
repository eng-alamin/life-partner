<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Models\Biodata;
use App\Models\BiodataPhoto;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

trait CreatesPhotos
{
    /** Call from setUp(): photos and Livewire temporary uploads go to throwaway disks. */
    protected function fakePhotoDisks(): void
    {
        Storage::fake('photos');
        Storage::fake('local');
        Storage::fake('public');
    }

    /** A photo row with real files on the fake photos disk. Approved unless said otherwise. */
    protected function photoFor(Biodata $biodata, array $attributes = []): BiodataPhoto
    {
        $code = Str::lower(Str::random(24));
        $path = $biodata->public_code.'/'.$code.'-large.jpg';
        $thumbPath = $biodata->public_code.'/'.$code.'-thumb.jpg';

        $bytes = $this->jpegBytes();

        Storage::disk('photos')->put($path, $bytes);
        Storage::disk('photos')->put($thumbPath, $bytes);

        $photo = new BiodataPhoto;
        $photo->forceFill(array_merge([
            'biodata_id' => $biodata->id,
            'code' => $code,
            'path' => $path,
            'thumb_path' => $thumbPath,
            'is_main' => false,
            'status' => 'approved',
            'sort_order' => 0,
        ], $attributes))->save();

        return $photo;
    }

    protected function photoUrl(Biodata $biodata, BiodataPhoto $photo, string $size = 'thumb'): string
    {
        return route('photos.show', ['biodata' => $biodata->public_code, 'photo' => $photo->code, 'size' => $size]);
    }

    /** A small real JPEG, built with GD (no temporary file that could disappear). */
    protected function jpegBytes(): string
    {
        $image = imagecreatetruecolor(400, 500);
        imagefill($image, 0, 0, (int) imagecolorallocate($image, 120, 160, 140));

        ob_start();
        imagejpeg($image, null, 80);

        return (string) ob_get_clean();
    }
}
