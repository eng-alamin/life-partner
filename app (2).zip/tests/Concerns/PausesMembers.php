<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Actions\Account\RequestAccountDeletion;
use App\Enums\DeactivationReason;
use App\Enums\HiddenSource;
use App\Models\Biodata;
use App\Models\User;
use App\Services\Biodata\BiodataHiding;

/**
 * Puts a member into one of the four "paused" states with the real code paths
 * (never by editing columns): hidden by the owner, hidden by staff, deactivated,
 * or waiting out the account deletion period.
 *
 * Needs CreatesStaff in the test class for the "staff_hidden" kind.
 */
trait PausesMembers
{
    /** @return array<string, array{0: string}> */
    public static function pauseKinds(): array
    {
        return [
            'hidden by owner' => ['owner_hidden'],
            'hidden by staff' => ['staff_hidden'],
            'deactivated' => ['deactivated'],
            'waiting for deletion' => ['deletion'],
        ];
    }

    /** Returns a fresh copy of the user, because the actions work on a locked copy. */
    protected function pauseMember(string $kind, User $user, Biodata $biodata): User
    {
        $hiding = app(BiodataHiding::class);

        match ($kind) {
            'owner_hidden' => $hiding->hide($biodata->fresh(), HiddenSource::Owner, $user),
            'staff_hidden' => $hiding->hide($biodata->fresh(), HiddenSource::Staff, $this->staff()),
            'deactivated' => $hiding->deactivate($biodata->fresh(), $user, DeactivationReason::Other),
            'deletion' => app(RequestAccountDeletion::class)($user, 'password'),
        };

        return $user->fresh();
    }
}
