<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Actions\Report\SubmitReport;
use App\Enums\BiodataType;
use App\Models\Biodata;
use App\Models\Report;
use App\Models\User;

trait CreatesReports
{
    /**
     * Files an open report through the real action, from a new verified member
     * about the given approved biodata (a new bride biodata when none is given).
     *
     * @return array{0: Report, 1: User, 2: Biodata} the report, the reporter and the reported biodata
     */
    protected function openReport(?Biodata $target = null, string $reason = 'fake_profile', ?string $details = null): array
    {
        $reporter = User::factory()->create();
        Biodata::factory()->approved()->ofType(BiodataType::Groom)->forUser($reporter)->create();

        $target ??= Biodata::factory()->approved()->ofType(BiodataType::Bride)->create();

        $report = app(SubmitReport::class)($reporter, $target->public_code, $reason, $details);

        return [$report, $reporter, $target];
    }
}
