<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Actions\Interest\SendInterest;
use App\Enums\BiodataType;
use App\Enums\GuardianRelation;
use App\Models\Biodata;
use App\Models\Guardian;
use App\Models\Interest;
use App\Models\User;
use Closure;
use Illuminate\Validation\ValidationException;

trait CreatesInterests
{
    /**
     * A verified, active member with an approved biodata of the given type.
     *
     * @param  array<string, mixed>  $attributes
     * @return array{0: User, 1: Biodata}
     */
    protected function member(BiodataType $type, array $attributes = []): array
    {
        $user = User::factory()->create();
        $biodata = Biodata::factory()->approved()->ofType($type)->forUser($user)->create($attributes);

        return [$user, $biodata];
    }

    protected function addGuardian(Biodata $biodata, bool $canApprove = true): void
    {
        $guardian = new Guardian;
        $guardian->forceFill([
            'biodata_id' => $biodata->getKey(),
            'name' => 'Test Guardian',
            'relation' => GuardianRelation::Father->value,
            'phone' => '01700000000',
            'can_approve' => $canApprove,
        ])->save();
    }

    protected function sendInterest(User $user, Biodata $receiver, ?string $message = null): Interest
    {
        return app(SendInterest::class)($user, $receiver->public_code, $message);
    }

    /**
     * Runs the call and checks that it was refused with the given message key
     * from lang/{locale}/interests.php, on the given form field.
     *
     * @param  array<string, int|string>  $replace
     */
    protected function assertRefused(Closure $call, string $key, string $field = 'form', array $replace = []): void
    {
        try {
            $call();
        } catch (ValidationException $e) {
            $this->assertSame(
                [__('interests.errors.'.$key, $replace)],
                $e->errors()[$field] ?? null,
                'Wrong refusal message for '.$key
            );

            return;
        }

        $this->fail('Expected the request to be refused with "'.$key.'", but it went through.');
    }
}
