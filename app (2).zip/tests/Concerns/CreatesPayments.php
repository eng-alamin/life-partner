<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Enums\PaymentStatus;
use App\Enums\SubscriptionStatus;
use App\Models\Payment;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\User;
use Closure;
use Illuminate\Validation\ValidationException;

/** Shared set-up for the payment review tests. */
trait CreatesPayments
{
    /**
     * A manual bKash payment that the member has submitted and staff still has to decide.
     *
     * @param  array<string, mixed>  $attributes
     */
    protected function underReview(array $attributes = [], ?Plan $plan = null, ?User $user = null): Payment
    {
        $plan ??= Plan::factory()->create(['price_minor' => 50000, 'credits' => 10]);

        return Payment::factory()
            ->forPlan($plan)
            ->status(PaymentStatus::UnderReview)
            ->create(array_merge([
                'user_id' => ($user ?? User::factory()->create())->getKey(),
                'gateway_ref' => 'ABC123XYZ9',
                'payer_number' => '01711111111',
                'submitted_at' => now(),
            ], $attributes));
    }

    /** The member of a payment, loaded by a query (lazy loading is switched off in tests). */
    protected function memberOf(Payment $payment): User
    {
        return User::query()->findOrFail($payment->user_id);
    }

    /** @param  array<string, mixed>  $attributes */
    protected function subscriptionFor(User $user, array $attributes = []): Subscription
    {
        $subscription = new Subscription;
        $subscription->forceFill(array_merge([
            'user_id' => $user->getKey(),
            'plan_code' => 'monthly',
            'plan_name' => 'Monthly membership',
            'daily_interest_limit' => 15,
            'status' => SubscriptionStatus::Active->value,
            'starts_at' => now()->subDay(),
            'ends_at' => now()->addDays(29),
        ], $attributes))->save();

        return $subscription;
    }

    /** Runs the work and returns the validation errors it raised; fails if it did not raise any. */
    protected function validationErrors(Closure $work): array
    {
        try {
            $work();
        } catch (ValidationException $e) {
            return $e->errors();
        }

        $this->fail('A validation error was expected.');
    }
}
