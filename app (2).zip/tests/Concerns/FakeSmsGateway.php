<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Services\Sms\SmsGateway;
use App\Services\Sms\SmsResult;

/** A gateway for tests: remembers every SMS and answers what the test told it to. */
final class FakeSmsGateway implements SmsGateway
{
    /** @var list<array{to: string, message: string}> */
    public array $sent = [];

    public bool $ready = true;

    public ?SmsResult $nextResult = null;

    /** Make isReady() throw, to prove a gateway problem cannot break the caller. */
    public bool $explode = false;

    public function isReady(): bool
    {
        if ($this->explode) {
            throw new \RuntimeException('gateway exploded');
        }

        return $this->ready;
    }

    public function send(string $localNumber, string $message): SmsResult
    {
        $result = $this->nextResult ?? SmsResult::sent('ref-'.(count($this->sent) + 1));

        if ($result->ok) {
            $this->sent[] = ['to' => $localNumber, 'message' => $message];
        }

        return $result;
    }

    /** The 6-digit code inside the newest SMS, or null. */
    public function lastCode(): ?string
    {
        $last = end($this->sent);

        if ($last === false || preg_match('/\b(\d{6})\b/', $last['message'], $match) !== 1) {
            return null;
        }

        return $match[1];
    }
}
