<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Actions\Interest\IssueGuardianLink;
use App\Actions\Interest\RespondToInterest;
use App\Enums\BiodataType;
use App\Enums\GuardianApprovalStatus;
use App\Enums\InterestStatus;
use App\Models\Biodata;
use App\Models\Interest;
use App\Models\User;

/** Shared set-up for the guardian approval tests (includes CreatesInterests). */
trait CreatesGuardianLinks
{
    use CreatesInterests;

    /**
     * A groom sent an interest, the bride accepted, and her guardian must approve.
     *
     * @return array{0: User, 1: User, 2: Interest, 3: Biodata, 4: Biodata} groom user, bride user, interest, groom biodata, bride biodata
     */
    protected function acceptedWithGuardian(array $groomAttributes = []): array
    {
        [$groomUser, $groom] = $this->member(BiodataType::Groom, $groomAttributes);
        [$brideUser, $bride] = $this->member(BiodataType::Bride);
        $this->addGuardian($bride);

        $interest = $this->sendInterest($groomUser, $bride);
        app(RespondToInterest::class)($brideUser, $interest->code, InterestStatus::Accepted);

        $interest = $interest->fresh();
        $this->assertSame(GuardianApprovalStatus::Pending, $interest->guardian_status);

        return [$groomUser, $brideUser, $interest, $groom, $bride];
    }

    protected function issueLink(User $receiverUser, Interest $interest): string
    {
        return app(IssueGuardianLink::class)($receiverUser, $interest->code);
    }
}
