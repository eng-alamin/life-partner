<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Models\Page;

trait CreatesPages
{
    /**
     * A saved page. Page has no factory and nothing is mass-assignable, so the columns are forced in.
     *
     * @param  array<string, mixed>  $attributes
     */
    protected function makePage(string $slug, array $attributes = []): Page
    {
        $page = new Page;
        $page->forceFill(array_merge([
            'slug' => $slug,
            'title_bn' => 'বাংলা শিরোনাম',
            'title_en' => 'English title',
            'body_bn' => 'বাংলা লেখা',
            'body_en' => 'English text',
            'is_published' => true,
        ], $attributes))->save();

        Page::forgetPublishedSlugs();

        return $page;
    }

    /** The input SavePage and PageForm expect. @param  array<string, mixed>  $overrides  @return array<string, mixed> */
    protected function pageInput(array $overrides = []): array
    {
        return array_merge([
            'title_bn' => 'নতুন শিরোনাম',
            'title_en' => 'New title',
            'body_bn' => 'নতুন লেখা',
            'body_en' => 'New text',
            'is_published' => true,
        ], $overrides);
    }
}
