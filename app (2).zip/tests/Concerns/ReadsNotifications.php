<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Enums\NotificationType;
use App\Models\User;
use App\Notifications\LifePartnerNotification;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Str;

/** Helpers for the notification tests. */
trait ReadsNotifications
{
    /**
     * Types sent on the in-app channel to one user (use after Notification::fake()).
     *
     * @return list<string>
     */
    protected function inAppTypes(User $user): array
    {
        return Notification::sent($user, LifePartnerNotification::class)
            ->filter(fn (LifePartnerNotification $n): bool => $n->via($user) === ['database'])
            ->map(fn (LifePartnerNotification $n): string => $n->type->value)
            ->values()
            ->all();
    }

    /** The in-app notification of this type sent to this user, or null (use after Notification::fake()). */
    protected function inAppNotification(User $user, NotificationType $type): ?LifePartnerNotification
    {
        return Notification::sent($user, LifePartnerNotification::class)
            ->first(fn (LifePartnerNotification $n): bool => $n->via($user) === ['database'] && $n->type === $type);
    }

    /** Writes a real in-app row now (no fake, no queue). @param  array<string, string>  $params */
    protected function giveNotification(User $user, NotificationType $type, array $params = []): DatabaseNotification
    {
        $notification = new LifePartnerNotification($type, $params, ['database']);

        // sendNow puts a new id only on its own copy, never on this object. So the id is
        // set here first; the copy keeps it and the row is found exactly.
        $notification->id = (string) Str::uuid();

        Notification::sendNow($user, $notification);

        return DatabaseNotification::query()->findOrFail($notification->id);
    }
}
